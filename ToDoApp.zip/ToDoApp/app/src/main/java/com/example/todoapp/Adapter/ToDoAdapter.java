package com.example.todoapp.Adapter;

import android.graphics.Paint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.todoapp.AddNewTask;
import com.example.todoapp.MainActivity;
import com.example.todoapp.Model.ToDoModel;
import com.example.todoapp.R;
import com.example.todoapp.Utils.DatabaseHelper;

import java.util.List;

public class ToDoAdapter extends RecyclerView.Adapter<ToDoAdapter.ViewHolder> {

    private List<ToDoModel> todoList;
    private final MainActivity activity;
    private final DatabaseHelper myDb;
    private int userId; // Logged-in user ID

    public ToDoAdapter(DatabaseHelper myDb, MainActivity activity) {
        this.myDb = myDb;
        this.activity = activity;
        this.userId = userId; // Initialize userId
    }

    public void setTasks(List<ToDoModel> todoList) {
        this.todoList = todoList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ToDoAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.task_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ToDoAdapter.ViewHolder holder, int position) {
        ToDoModel item = todoList.get(position);

        holder.taskTitle.setText(item.getTask());
        holder.taskDescription.setText(item.getDescription());
        holder.checkBox.setChecked(item.getStatus() != 0);

        // Strike-through effect for completed tasks
        if (item.getStatus() != 0) {
            holder.taskTitle.setPaintFlags(holder.taskTitle.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            holder.taskDescription.setPaintFlags(holder.taskDescription.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        } else {
            holder.taskTitle.setPaintFlags(holder.taskTitle.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
            holder.taskDescription.setPaintFlags(holder.taskDescription.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
        }

        // Checkbox onClick listener
        holder.checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                myDb.updateStatus(item.getId(), 1);
                holder.taskTitle.setPaintFlags(holder.taskTitle.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                holder.taskDescription.setPaintFlags(holder.taskDescription.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            } else {
                myDb.updateStatus(item.getId(), 0);
                holder.taskTitle.setPaintFlags(holder.taskTitle.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
                holder.taskDescription.setPaintFlags(holder.taskDescription.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
            }
        });

        // Edit task on item click
        holder.itemView.setOnClickListener(v -> {
            AddNewTask dialog = AddNewTask.newInstance();
            dialog.setArguments(createBundle(item));
            dialog.show(activity.getSupportFragmentManager(), AddNewTask.TAG);
        });
    }

    private Bundle createBundle(ToDoModel item) {
        Bundle bundle = new Bundle();
        bundle.putInt("id", item.getId());
        bundle.putString("task", item.getTask());
        bundle.putString("description", item.getDescription());
        bundle.putInt("userId", userId); // Include userId for reference
        return bundle;
    }

    @Override
    public int getItemCount() {
        return todoList == null ? 0 : todoList.size();
    }

    // New method to delete a task
    public void deleteTask(int position) {
        ToDoModel item = todoList.get(position);
        myDb.deleteTask(item.getId()); // Remove from database
        todoList.remove(position);    // Remove from list
        notifyItemRemoved(position); // Notify RecyclerView of item removal
    }

    // New method to edit a task
    public void editItem(int position) {
        ToDoModel item = todoList.get(position);
        AddNewTask dialog = AddNewTask.newInstance();
        dialog.setArguments(createBundle(item)); // Pass data to dialog
        dialog.show(activity.getSupportFragmentManager(), AddNewTask.TAG);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        CheckBox checkBox;
        TextView taskTitle;
        TextView taskDescription;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            checkBox = itemView.findViewById(R.id.todoCheckBox);
            taskTitle = itemView.findViewById(R.id.taskTitle);
            taskDescription = itemView.findViewById(R.id.taskDescription);
        }
    }
}
